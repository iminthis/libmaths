# libmaths
A Python library created to assist programmers with complex mathematical functions
